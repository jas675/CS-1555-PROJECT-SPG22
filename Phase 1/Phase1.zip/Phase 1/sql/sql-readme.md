# SQL DDL

The SQL DDL files are contained in this repository
